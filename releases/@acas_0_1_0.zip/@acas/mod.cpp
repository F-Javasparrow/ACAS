name = "Advanced Combat Armor System"; 
picture = "mod.paa";
hidePicture = "false";
hideName = "false";
description = "Advanced Combat Armor System";
logo = "mod.paa";
logoOver = "mod.paa";
